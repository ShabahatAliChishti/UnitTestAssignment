﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private const string CREATE_TICKET = "createTicket";
        private const string CLEAR_FORM = "clearForm";
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            LotteryTicket ticket = new LotteryTicket();

            // Set the ticket to the ViewBag
            ViewBag.Ticket = ticket;
            return View();
        }

        [HttpPost]
        public IActionResult Index(LotteryTicket ticket, string action)
        {
            if (action == CREATE_TICKET)
            {
                // Validate user input
                if (ModelState.IsValid)
                {
                    // Generate the winning numbers
                    int[] winningNumbers = GenerateWinningNumbers();
                    List<int> matchingNumbersList = ticket.GetMatchingNumbers(winningNumbers);
                    int[] matchingNumbers = matchingNumbersList.ToArray();

                    // Set the winning and matching numbers to the ViewBag
                    ((dynamic)ViewBag).WinningNumbers = winningNumbers;
                    if (matchingNumbersList.Count > 0)
                    {
                        ((dynamic)ViewBag).MatchingNumbers = matchingNumbers;
                    }
                    else
                    {
                        ((dynamic)ViewBag).MatchingNumbers = matchingNumbers;
                    }
                }
            }
            else if (action == CLEAR_FORM)
            {
                // Initialize a new empty ticket
                // Create a new instance of the LotteryTicket object to clear the form values
                ticket = new LotteryTicket();

                // Return the view with the cleared form values
                return View(ticket);
            }

            return View(ticket);
        }

        private int[] GenerateWinningNumbers()
        {
            List<int> winningNumbers = new List<int>();

            // Generate 4 random winning numbers between 1 and 72
            Random random = new Random();
            for (int i = 0; i < 4; i++)
            {
                int number = random.Next(1, 73);
                while (winningNumbers.Contains(number))
                {
                    number = random.Next(1, 73);
                }
                winningNumbers.Add(number);
            }

            return winningNumbers.ToArray();
        }

    }
}