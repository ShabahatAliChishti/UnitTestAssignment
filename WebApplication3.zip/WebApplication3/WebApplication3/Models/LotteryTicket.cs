﻿namespace WebApplication3.Models
{
    public class LotteryTicket
    {
        public int FirstNumber { get; set; }
        public int SecondNumber { get; set; }
        public int ThirdNumber { get; set; }
        public int FourthNumber { get; set; }
        public int NumberMatching { get; set; }

        public LotteryTicket()
        {
            // Generate the 4 winning numbers randomly between 1 and 72
            Random rnd = new Random();
            FirstNumber = rnd.Next(1, 73);
            SecondNumber = rnd.Next(1, 73);
            ThirdNumber = rnd.Next(1, 73);
            FourthNumber = rnd.Next(1, 73);
        }

        public int CompareTo(LotteryTicket otherTicket)
        {
            // Compare the current ticket to the other ticket
            int matchingNumbers = 0;

            if (FirstNumber == otherTicket.FirstNumber)
            {
                matchingNumbers++;
            }
            if (SecondNumber == otherTicket.SecondNumber)
            {
                matchingNumbers++;
            }
            if (ThirdNumber == otherTicket.ThirdNumber)
            {
                matchingNumbers++;
            }
            if (FourthNumber == otherTicket.FourthNumber)
            {
                matchingNumbers++;
            }

            return matchingNumbers;
        }
        public List<int> GetMatchingNumbers(int[] winningNumbers)
        {
            List<int> matchingNumbers = new List<int>();

            if (winningNumbers.Contains(FirstNumber))
            {
                matchingNumbers.Add(FirstNumber);
            }
            if (winningNumbers.Contains(SecondNumber))
            {
                matchingNumbers.Add(SecondNumber);
            }
            if (winningNumbers.Contains(ThirdNumber))
            {
                matchingNumbers.Add(ThirdNumber);
            }
            if (winningNumbers.Contains(FourthNumber))
            {
                matchingNumbers.Add(FourthNumber);
            }

            NumberMatching = matchingNumbers.Count;

            return matchingNumbers;
        }
    }

}
